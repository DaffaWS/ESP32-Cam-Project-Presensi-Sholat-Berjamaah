#include "esp_camera.h"
#include <WiFi.h>
#include <HTTPClient.h>

//
// WARNING!!! Make sure that you have either selected ESP32 Wrover Module,
//            or another board which has PSRAM enabled
//

// Select camera model
//#define CAMERA_MODEL_WROVER_KIT
//#define CAMERA_MODEL_ESP_EYE
//#define CAMERA_MODEL_M5STACK_PSRAM
//#define CAMERA_MODEL_M5STACK_WIDE
#define CAMERA_MODEL_AI_THINKER

#include "camera_pins.h"

const char *ssid = "ISI DENGAN NAMA WIFI KALIAN";
const char *password = "ISI DENGAN PASSWORD WIFI KALIAN";
const char *deviceLabel = "ISI DENGAN ESP32 NYA MAU TARUH DI MANA";
String scriptURL = "CONTOH SCRIPT: https://script.google.com/macros/s/DHFBGSKDFBSDBFSKDFBVLSDFSD/exec";
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 20000;
constexpr uint32_t ABSEN_COOLDOWN_MS = 7000;
constexpr size_t FACE_ID_CACHE_SIZE = 16;

void startCameraServer();
bool kirimDataAbsensi(int id, String *response = nullptr);
void onFaceRecognized(int faceId);
bool connectWiFi(uint32_t timeoutMs);
void ensureWiFiConnected();
bool queueAbsenRequest(int id, String *message = nullptr);

uint32_t lastWiFiRetryMs = 0;
int lastRecognizedFaceId = -999;
uint32_t lastRecognizedFaceMs = 0;
volatile int pendingAbsenId = -1;
volatile bool pendingAbsenRequest = false;

struct FaceCooldownEntry {
  int faceId;
  uint32_t lastSentMs;
};

FaceCooldownEntry faceCooldowns[FACE_ID_CACHE_SIZE] = {};

bool connectWiFi(uint32_t timeoutMs) {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true, true);
  delay(500);
  WiFi.begin(ssid, password);
  WiFi.setSleep(false);

  Serial.print("WiFi connecting");
  uint32_t startMs = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startMs) < timeoutMs) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi connected. IP: ");
    Serial.println(WiFi.localIP());
    return true;
  }

  Serial.println("WiFi gagal terhubung");
  return false;
}

void ensureWiFiConnected() {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  uint32_t now = millis();
  if (now - lastWiFiRetryMs < 5000) {
    return;
  }

  lastWiFiRetryMs = now;
  Serial.println("Mencoba reconnect WiFi...");
  connectWiFi(8000);
}

int findFaceCooldownIndex(int faceId) {
  for (size_t i = 0; i < FACE_ID_CACHE_SIZE; i++) {
    if (faceCooldowns[i].faceId == faceId) {
      return (int)i;
    }
  }
  return -1;
}

bool isFaceCooldownActive(int faceId, uint32_t nowMs) {
  int index = findFaceCooldownIndex(faceId);
  if (index < 0) {
    return false;
  }
  return (nowMs - faceCooldowns[index].lastSentMs) < ABSEN_COOLDOWN_MS;
}

void updateFaceCooldown(int faceId, uint32_t nowMs) {
  int index = findFaceCooldownIndex(faceId);
  if (index >= 0) {
    faceCooldowns[index].lastSentMs = nowMs;
    return;
  }

  for (size_t i = 0; i < FACE_ID_CACHE_SIZE; i++) {
    if (faceCooldowns[i].faceId < 0) {
      faceCooldowns[i].faceId = faceId;
      faceCooldowns[i].lastSentMs = nowMs;
      return;
    }
  }

  size_t oldestIndex = 0;
  for (size_t i = 1; i < FACE_ID_CACHE_SIZE; i++) {
    if (faceCooldowns[i].lastSentMs < faceCooldowns[oldestIndex].lastSentMs) {
      oldestIndex = i;
    }
  }
  faceCooldowns[oldestIndex].faceId = faceId;
  faceCooldowns[oldestIndex].lastSentMs = nowMs;
}

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();

  for (size_t i = 0; i < FACE_ID_CACHE_SIZE; i++) {
    faceCooldowns[i].faceId = -1;
    faceCooldowns[i].lastSentMs = 0;
  }

  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 10000000;
  config.pixel_format = PIXFORMAT_JPEG;
  if(psramFound()){
    config.frame_size = FRAMESIZE_SVGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
  } else {
    config.frame_size = FRAMESIZE_VGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
  }

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  // camera init
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  sensor_t * s = esp_camera_sensor_get();
  //initial sensors are flipped vertically and colors are a bit saturated
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1);//flip it back
    s->set_brightness(s, 1);//up the blightness just a bit
    s->set_saturation(s, -2);//lower the saturation
  }
  //drop down frame size for higher initial frame rate
  s->set_framesize(s, FRAMESIZE_QVGA);

#if defined(CAMERA_MODEL_M5STACK_WIDE)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

  connectWiFi(WIFI_CONNECT_TIMEOUT_MS);

  startCameraServer();

  Serial.print("Camera Ready! Use 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("' to connect");
  Serial.println("Langkah awal: aktifkan Face Detection dan Face Recognition di browser, lalu enroll wajah siswa.");
}

void loop() {
  ensureWiFiConnected();
  if (pendingAbsenRequest && pendingAbsenId >= 0) {
    int idToSend = pendingAbsenId;
    pendingAbsenRequest = false;
    pendingAbsenId = -1;

    String response;
    bool ok = kirimDataAbsensi(idToSend, &response);
    Serial.printf("Face ID %d -> %s\n", idToSend, ok ? "ABSEN TERKIRIM" : "ABSEN DITOLAK");
    if (response.length() > 0) {
      Serial.println(response);
    }
  }
  delay(50);
}

bool kirimDataAbsensi(int id, String *response) {
  if (id < 0) {
    if (response != nullptr) {
      *response = "ID wajah tidak valid";
    }
    return false;
  }

  uint32_t nowMs = millis();
  if (isFaceCooldownActive(id, nowMs)) {
    if (response != nullptr) {
      *response = "ID ini baru saja absen, tunggu beberapa detik";
    }
    return false;
  }

  if (WiFi.status() != WL_CONNECTED) {
    if (response != nullptr) {
      *response = "WiFi belum terhubung";
    }
    return false;
  }

  HTTPClient http;
  char url[320];
  snprintf(url, sizeof(url), "%s?id=%d&device=%s", scriptURL.c_str(), id, deviceLabel);

  Serial.print("Kirim ke URL: ");
  Serial.println(url);

  if (!http.begin(url)) {
    if (response != nullptr) {
      *response = "HTTP begin gagal";
    }
    return false;
  }

  http.setTimeout(10000);
  int httpCode = http.GET();
  String payload = httpCode > 0 ? http.getString() : http.errorToString(httpCode);
  http.end();

  if (response != nullptr) {
    *response = payload;
  }

  if (httpCode >= 200 && httpCode < 300) {
    updateFaceCooldown(id, nowMs);
    Serial.printf("Absensi ID %d berhasil. HTTP %d\n", id, httpCode);
    Serial.println(payload);
    return true;
  }

  Serial.printf("Absensi ID %d gagal. HTTP %d\n", id, httpCode);
  Serial.println(payload);
  return false;
}

bool queueAbsenRequest(int id, String *message) {
  if (id < 0) {
    if (message != nullptr) {
      *message = "ID wajah tidak valid";
    }
    return false;
  }

  uint32_t nowMs = millis();
  if (isFaceCooldownActive(id, nowMs)) {
    if (message != nullptr) {
      *message = "ID ini baru saja absen, tunggu beberapa detik";
    }
    return false;
  }

  pendingAbsenId = id;
  pendingAbsenRequest = true;
  if (message != nullptr) {
    *message = "Absensi dijadwalkan";
  }
  return true;
}

void onFaceRecognized(int faceId) {
  if (faceId < 0) {
    return;
  }

  uint32_t now = millis();
  if (faceId == lastRecognizedFaceId && (now - lastRecognizedFaceMs) < ABSEN_COOLDOWN_MS) {
    return;
  }

  lastRecognizedFaceId = faceId;
  lastRecognizedFaceMs = now;
  String message;
  if (queueAbsenRequest(faceId, &message)) {
    Serial.printf("Face ID %d dikenali, absensi dijadwalkan...\n", faceId);
  } else {
    Serial.printf("Face ID %d dikenali, tapi tidak dikirim: %s\n", faceId, message.c_str());
  }
}
